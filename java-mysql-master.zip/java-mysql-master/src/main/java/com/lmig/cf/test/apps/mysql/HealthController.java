package com.lmig.cf.test.apps.mysql;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lmig.cf.test.apps.mysql.people.Person;
import com.lmig.cf.test.apps.mysql.people.PersonRepository;

@Controller
public class HealthController {

    @Autowired
    private PersonRepository personRepository;

    @RequestMapping("/")
    public String home() {
        return "redirect:/health";
    }

    @RequestMapping(value = "/health", method = RequestMethod.GET)
    public @ResponseBody
    Message health() throws IOException {

        long peopleCount = personRepository.count();

        Person dave = new Person();
        dave.setFirstName("David");
        dave.setLastName("Ehringer");
        dave = personRepository.save(dave);
        assertNotNull(dave.getId());

        Person finn = new Person();
        finn.setFirstName("Finnegan");
        finn.setLastName("Ehringer");
        finn = personRepository.save(finn);
        assertNotNull(finn.getId());

        assertEquals(peopleCount + 2, personRepository.count());

        return new Message("Successfully used MySQL service.");
    }

}