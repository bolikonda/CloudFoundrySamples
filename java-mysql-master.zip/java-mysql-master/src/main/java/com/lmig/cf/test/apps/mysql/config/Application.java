package com.lmig.cf.test.apps.mysql.config;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.orm.jpa.EntityScan;
import org.springframework.cloud.config.java.ServiceScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.rest.webmvc.config.RepositoryRestMvcConfiguration;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.vendor.Database;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;

@Configuration
@EnableAutoConfiguration
@ComponentScan("com.lmig.cf.test.apps.mysql")
@ServiceScan
@EnableJpaRepositories("com.lmig.cf.test.apps.mysql.people")
@EntityScan("com.lmig.cf.test.apps.mysql.people")
@Import(RepositoryRestMvcConfiguration.class)
public class Application {
    
    // The @ServiceScan performs the magic of making a DataSource available in the application context

    @Bean
    public JpaVendorAdapter jpaVendorAdapter() {
        // Need to manually specify this so we can enable DDL generation
        HibernateJpaVendorAdapter hibernateJpaVendorAdapter = new HibernateJpaVendorAdapter();
        hibernateJpaVendorAdapter.setShowSql(true);
        hibernateJpaVendorAdapter.setGenerateDdl(true);
        hibernateJpaVendorAdapter.setDatabase(Database.MYSQL);
        return hibernateJpaVendorAdapter;
    }
}