# Java MySQL Service

This application is part of the suite of applications used in the automated Cloud Foundry platform
testing. It is hosted in the examples project because while it is a simple application, it 
may be informative to developers deploying applications to the platform. 

This is simple Java Web App that shows how to use a MySQL service bound to the app.

## Building the App

```
mvn clean package
```

## Deploying to Cloud Foundry

This app depends on a MySQL service named `example-mysql` being provisioned in your space.

```
cf marketplace
cf create-service p-mysql 500mb-dev example-mysql
cf push
```
The configuration in `manifest.yml` will be used.

Hit the root of the app. It will read and write data to the database as seen in the `HealthController`.